require 'socket'

s= Tpsocket.new ' localhost' , 8989

s.write ("/tmp/testfiles/#{ARGV [ 0]}.c/n")

s.each_line do |line| 
    puts line 
end

s.close 
endtime = process.clock_gettime(Process::CLOCK::MONOTONIC)

elapsed = endtime - startime 
puts "Elapsed: #{elapsed} (#{ARGV)[0]}" 













